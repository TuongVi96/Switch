module.exports = [
  {
    title: 'Banner 1',
    intro: 'Short banner 1 dest'
  },
  {
    title: 'Banner 2',
    intro: 'Short banner 2 dest'
  }
]
